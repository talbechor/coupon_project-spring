package com.coupon.coupon_projectspring.controller;
import com.coupon.coupon_projectspring.beans.UserDetails;
import com.coupon.coupon_projectspring.exceptions.LoginException;
import com.coupon.coupon_projectspring.exceptions.NotExistsException;
import com.coupon.coupon_projectspring.login.LoginManager;
import com.coupon.coupon_projectspring.service.AdminServiceIml;
import com.coupon.coupon_projectspring.service.ClientService;
import com.coupon.coupon_projectspring.service.CompanyServiceIml;
import com.coupon.coupon_projectspring.service.CustomerServiceIml;
import com.coupon.coupon_projectspring.utils.JWTUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/login")
@RequiredArgsConstructor
public class LoginController {
    private final LoginManager loginManager;
    private final AdminServiceIml adminService;
    private final CompanyServiceIml companyService;
    private final CustomerServiceIml customerService;
    private final JWTUtils jwtUtils;


    @PostMapping("/login")
    public ResponseEntity<?> userLogin(@RequestBody UserDetails userDetails) throws NotExistsException, LoginException {
        if (loginManager.login(userDetails)!= null) {
            return new ResponseEntity<>(jwtUtils.generateToken(userDetails), HttpStatus.OK);
        } else {
            throw new LoginException();
        }

    }
}
