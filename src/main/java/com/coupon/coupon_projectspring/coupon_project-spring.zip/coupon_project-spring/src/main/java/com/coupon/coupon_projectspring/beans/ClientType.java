package com.coupon.coupon_projectspring.beans;

public enum ClientType {
    ADMIN,COMPANY,CUSTOMER,COUPON;
}
